
import java.util.*;

/**
 * 
 */
public class Security guard extends Person {

    /**
     * Default constructor
     */
    public Security guard() {
    }

    /**
     * 
     */
    public void staff ID;

}