
import java.util.*;

/**
 * 
 */
public class Mentor extends Teacher {

    /**
     * Default constructor
     */
    public Mentor() {
    }

    /**
     * 
     */
    public void emailAdress;


}