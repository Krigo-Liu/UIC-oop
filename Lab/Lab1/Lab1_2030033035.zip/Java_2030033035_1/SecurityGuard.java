
import java.util.*;

/**
 * 
 */
public class SecurityGuard extends Person {

    /**
     * Default constructor
     */
    public SecurityGuard() {
    }

    /**
     * 
     */
    public void staffId;

}