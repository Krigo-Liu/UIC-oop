
import java.util.*;

/**
 * 
 */
public class Teacher extends Person {

    /**
     * Default constructor
     */
    public Teacher() {
    }

    /**
     * 
     */
    public void officeNumber;

    /**
     * 
     */
    public void staffId;

    /**
     * 
     */
    public void officePhoneNumber;


}