
import java.util.*;

/**
 * 
 */
public class Person extends Person {

    /**
     * Default constructor
     */
    public Person() {
    }

    /**
     * 
     */
    public void mobilePhoneNumber;

}