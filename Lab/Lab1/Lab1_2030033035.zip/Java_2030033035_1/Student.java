
import java.util.*;

/**
 * 
 */
public class Student extends Person {

    /**
     * Default constructor
     */
    public Student() {
    }

    /**
     * 
     */
    public void studentId;

    /**
     * 
     */
    public void dormitoryNumber;

    /**
     * 
     */
    public void major;

    /**
     * 
     */
    public void homeAddress;

    /**
     * 
     */
    public void Operation1() {
        // TODO implement here
    }

}