
import java.util.*;

/**
 * 
 */
public class Professor extends Teacher {

    /**
     * Default constructor
     */
    public Professor() {
    }



}