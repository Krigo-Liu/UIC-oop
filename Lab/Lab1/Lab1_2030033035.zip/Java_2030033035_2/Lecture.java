
import java.util.*;

/**
 * 
 */
public class Lecture extends Teacher {

    /**
     * Default constructor
     */
    public Lecture() {
    }



}