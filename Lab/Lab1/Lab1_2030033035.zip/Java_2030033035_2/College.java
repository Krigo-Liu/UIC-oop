
import java.util.*;

/**
 * 
 */
public class College {

    /**
     * Default constructor
     */
    public College() {
    }

    /**
     * 
     */
    public void Student;

    /**
     * 
     */
    public void Teacher;




}