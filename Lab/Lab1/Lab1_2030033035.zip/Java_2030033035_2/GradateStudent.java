
import java.util.*;

/**
 * 
 */
public class GradateStudent extends Student {

    /**
     * Default constructor
     */
    public GradateStudent() {
    }

}