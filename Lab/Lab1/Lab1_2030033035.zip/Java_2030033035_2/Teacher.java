
import java.util.*;

/**
 * 
 */
public class Teacher {

    /**
     * Default constructor
     */
    public Teacher() {
    }


}