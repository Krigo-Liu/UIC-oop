
import java.util.*;

/**
 * 
 */
public class TA extends Class2 {

    /**
     * Default constructor
     */
    public TA() {
    }




}