
import java.util.*;

/**
 * 
 */
public class Student {

    /**
     * Default constructor
     */
    public Student() {
    }


}