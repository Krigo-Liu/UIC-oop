
import java.util.*;

/**
 * 
 */
public class Class1 extends TA {

    /**
     * Default constructor
     */
    public Class1() {
    }

}