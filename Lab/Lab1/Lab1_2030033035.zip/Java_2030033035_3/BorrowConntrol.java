
import java.util.*;

/**
 * 
 */
public class BorrowConntrol {

    /**
     * Default constructor
     */
    public BorrowConntrol() {
    }

}