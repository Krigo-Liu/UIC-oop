
import java.util.*;

/**
 * 
 */
public class Book {

    /**
     * Default constructor
     */
    public Book() {
    }

    /**
     * 
     */
    public void isbnNumber;

    /**
     * 
     */
    public void statusIndicating;

}