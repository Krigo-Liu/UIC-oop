
import java.util.*;

/**
 * 
 */
public class UndergraduateStudent extends Student {

    /**
     * Default constructor
     */
    public UndergraduateStudent() {
    }

}