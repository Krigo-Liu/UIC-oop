
import java.util.*;

/**
 * 
 */
public interface User {

}