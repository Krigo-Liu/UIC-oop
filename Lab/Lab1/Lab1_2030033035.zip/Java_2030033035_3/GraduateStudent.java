
import java.util.*;

/**
 * 
 */
public class GraduateStudent extends Student {

    /**
     * Default constructor
     */
    public GraduateStudent() {
    }

}