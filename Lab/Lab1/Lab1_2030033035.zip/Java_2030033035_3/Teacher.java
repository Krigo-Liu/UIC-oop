
import java.util.*;

/**
 * 
 */
public class Teacher {

    /**
     * Default constructor
     */
    public Teacher() {
    }

    /**
     * 
     */
    public void staffIdNumber;

}